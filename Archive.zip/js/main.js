$(document).ready(function() {

  $(function() {
    $('.scroll-down').click (function() {
      $('html, body').animate({scrollTop: $('section.ok').offset().top }, 'slow');
      return false;
    });
  });
/*================================
=            search-sec            =
================================*/
(function($){
    var searchOpen = $('.icon-search2');
    var searchClose = $('.fa-times');
    var searchInput = $('.input');
    searchOpen.click(function(){
         $(this).css({
          display:'none',
         });
         searchClose.css({
          display   :'block',
         });
         searchInput.css({
          display   :'block',
         });
         // $('.input').slideDown(400);
      // $('.input').slideToggle();
  
    });
    searchClose.click(function(){
      $(this).css({
        display:'none',
      });
      searchOpen.css({
        display:'block',
      });
      $('.input').slideUp(0);
    });
  })(jQuery);  
   
/*================================
  =    hamburger-menu           =
================================*/
     $('.hamburger-menu').click(function(event) {
        $(this).toggleClass('mm-close');
        $('.cc-navigation').slideToggle();
        $(this).toggleClass('sub-menu');
      });
  
 
/*Scroll to top when arrow up clicked BEGIN*/
$(window).scroll(function() {
  var height = $(window).scrollTop();
  if (height > 100) {
      $('#back2Top').fadeIn();
  } else {
      $('#back2Top').fadeOut();
  }
});
  $("#back2Top").click(function(event) {
      event.preventDefault();
      $("html, body").animate({ scrollTop: 0 }, "slow");
      return false;
  });

/*Scroll to top when arrow up clicked END*/



 /*=============================================
 =            owl carousel            =
 =============================================*/
/* Owl Carousel */

$('.cc_banner').owlCarousel({
  autoplayTimeout:7000,
  items:1,
  margin:0,
//   stagePadding:30,
//   smartSpeed:450,
  loop: true,
  autoplay: true,
  responsive : {
    768 : {
        margin: 30
    }
}
});


$('.testimonials').owlCarousel({
	  center: true,
    loop:true,
    margin:0,
    nav:false,
    items: 3,
    
    smartSpeed: 750,
    navText: false,
    autoplay: false,
    responsive : {
	    0 : {
	    	items: 1
	    },
	    768 : {
	    	items: 2
      },
      1200:{
        stagePadding:-90,
        items: 3
      }
	}

});


$('.products-homepage').owlCarousel({
    center: true,
    items:1,
    loop:false,
    margin:10,
    autoplay: false,
    dots: false,
    responsive:{
        600:{
            items:2
        },
        1000:{
          items:3,
          loop: false,
          nav: false
      },
      1200:{
        items: 4
      }
    }
})
$(function() {
  var owl = $('.products-homepage'),
      owlOptions = {
          loop: false,
          margin: 10,
          responsive:{
            600:{
                items:2
            },
            1000:{
              items:3,
              loop: false,
              nav: false
          },
          1200:{
            items: 4
          }
        }
      };

  if ( $(window).width() < 1200 ) {
      var owlActive = owl.owlCarousel(owlOptions);
  } else {
      owl.addClass('off');
  }

  $(window).resize(function() {
      if ( $(window).width() < 1200 ) {
          if ( $('.products-homepage').hasClass('off') ) {
              var owlActive = owl.owlCarousel(owlOptions);
              owl.removeClass('off');
          }
      } else {
          if ( !$('.products-homepage').hasClass('off') ) {
              owl.addClass('off').trigger('destroy.owl.carousel');
              owl.find('.owl-stage-outer').children(':eq(0)').unwrap();
          }
      }
  });
});

 /*=====  End of owl carousel  ======*/
 
     
  
  
 
  
   });
  